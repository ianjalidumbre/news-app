class CountryModel{
  String countryName;
  String initials;

  CountryModel(this.countryName, this.initials);
}