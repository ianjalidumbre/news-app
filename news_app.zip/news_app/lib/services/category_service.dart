class CategoryService {
  List<String> categories = [
    'general',
    'business',
    'entertainment',
    'health',
    'science',
    'sports',
    'technology',
  ];

  List<String> getAllCategories(){
    return categories;
}
}
